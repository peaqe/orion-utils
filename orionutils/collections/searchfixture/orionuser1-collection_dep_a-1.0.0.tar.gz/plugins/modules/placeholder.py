"""Empty module plugin."""
